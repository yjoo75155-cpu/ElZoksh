يوميات الزوكش V10 - Android wrapper

المشروع يحتوي على نسخة الويب داخل app/src/main/assets/www.
لبناء APK تحتاج Android SDK + Gradle/Android Studio.
بعد تثبيت المتطلبات:
  gradle assembleDebug
وسيظهر APK في:
  app/build/outputs/apk/debug/app-debug.apk

ملاحظة: النسخة الحالية تعمل بالكامل Offline داخل WebView، وتستخدم localStorage.
صلاحية الإشعارات مضافة للمشروع، لكن نظام تنبيهات الخلفية الحقيقي يحتاج ربطه بـ AlarmManager/WorkManager في مرحلة لاحقة.
