package com.zoksh.yawmeyat;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

public class ReminderScheduler {
    public static final String PREF = "zoksh_reminders";
    public static void scheduleAll(Context c) {
        android.content.SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String raw = p.getString("items", "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i=0;i<a.length();i++) {
                JSONObject r=a.getJSONObject(i);
                if (r.optBoolean("enabled", true)) schedule(c, r.optInt("id", i), r.optLong("timeMs",0),
                    r.optString("title","يوميات الزوكش"), r.optString("text","عندك تذكير"));
            }
        } catch(Exception ignored) {}
    }
    public static void schedule(Context c, int id, long timeMs, String title, String text) {
        if (timeMs <= System.currentTimeMillis()) return;
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent in=new Intent(c, NotificationReceiver.class);
        in.putExtra("title", title); in.putExtra("text", text);
        PendingIntent pi=PendingIntent.getBroadcast(c,id,in,PendingIntent.FLAG_UPDATE_CURRENT |
            (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        if (Build.VERSION.SDK_INT>=23) {
            if (Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,timeMs,pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,timeMs,pi);
            }
        } else am.setExact(AlarmManager.RTC_WAKEUP,timeMs,pi);
    }
    public static void cancel(Context c, int id) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent in=new Intent(c,NotificationReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(c,id,in,PendingIntent.FLAG_UPDATE_CURRENT |
            (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        am.cancel(pi);
    }
}
