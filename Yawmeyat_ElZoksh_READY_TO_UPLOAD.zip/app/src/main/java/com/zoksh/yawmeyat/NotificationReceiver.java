package com.zoksh.yawmeyat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class NotificationReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "zoksh_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("title");
        String text = intent.getStringExtra("text");
        if (title == null || title.trim().isEmpty()) title = "يوميات الزوكش";
        if (text == null || text.trim().isEmpty()) text = "عندك تذكير دلوقتي 👀";

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "تذكيرات يوميات الزوكش",
                NotificationManager.IMPORTANCE_HIGH
            );
            ch.setDescription("تنبيهات المهام والتذكيرات في يوميات الزوكش");
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
        }

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
            context, (int)(System.currentTimeMillis() & 0x7fffffff),
            open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0)
        );

        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new android.app.Notification.Builder(context, CHANNEL_ID)
            : new android.app.Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
         .setContentTitle(title)
         .setContentText(text)
         .setStyle(new android.app.Notification.BigTextStyle().bigText(text))
         .setAutoCancel(true)
         .setContentIntent(pi)
         .setVibrate(new long[]{0,250,150,250});

        nm.notify((int)(System.currentTimeMillis() & 0x7fffffff), b.build());
    }
}
