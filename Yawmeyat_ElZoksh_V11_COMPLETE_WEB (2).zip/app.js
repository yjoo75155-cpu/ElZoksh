
(() => {
"use strict";

const KEY="zoksh_v11_data";
const defaults={
  profile:{name:"زوكش"},
  finance:{income:8000,fixed:3000},
  expenses:[],
  savings:[],
  goals:[],
  installments:[],
  tasks:[],
  habits:[],
  reminders:[],
  chat:[],
  xp:0,
  theme:"dark",
  onboarded:false
};
let data=load();
let selectedDate=todayKey();
let calendarDate=new Date();
let toastTimer=null;

function $(id){return document.getElementById(id)}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function todayKey(d=new Date()){return d.toISOString().slice(0,10)}
function money(n){return `${Math.round(Number(n)||0).toLocaleString("ar-EG")} ج`}
function load(){try{return Object.assign(structuredClone(defaults),JSON.parse(localStorage.getItem(KEY)||"{}"))}catch{return structuredClone(defaults)}}
function save(){localStorage.setItem(KEY,JSON.stringify(data)); renderAll()}
function uid(){return Date.now()+Math.floor(Math.random()*10000)}
function notify(t){clearTimeout(toastTimer);let x=document.querySelector(".toast");if(!x){x=document.createElement("div");x.className="toast";document.body.appendChild(x)}x.textContent=t;x.classList.add("show");toastTimer=setTimeout(()=>x.classList.remove("show"),2200)}
function askValue(label,def=""){const x=prompt(label,def);return x===null?null:x.trim()}
function num(label,def=0){const x=prompt(label,String(def));if(x===null)return null;const n=Number(x);return Number.isFinite(n)?n:0}

window.go=function(page){
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
  const el=$(page);if(el)el.classList.add("active");
  document.querySelectorAll(".nav button[data-p]").forEach(b=>b.classList.toggle("active",b.dataset.p===page));
  window.scrollTo({top:0,behavior:"smooth"});renderAll();
};
window.openSearch=function(){
  const q=askValue("ابحث في مصاريفك ومهامك وأهدافك وعاداتك:");
  if(!q)return;
  const hits=[];
  data.expenses.forEach(x=>{if(JSON.stringify(x).includes(q))hits.push(`💸 مصروف: ${x.title} — ${money(x.amount)}`)});
  data.tasks.forEach(x=>{if(JSON.stringify(x).includes(q))hits.push(`✅ مهمة: ${x.title}`)});
  data.goals.forEach(x=>{if(JSON.stringify(x).includes(q))hits.push(`🎯 هدف: ${x.title}`)});
  data.habits.forEach(x=>{if(JSON.stringify(x).includes(q))hits.push(`🔥 عادة: ${x.title}`)});
  data.installments.forEach(x=>{if(JSON.stringify(x).includes(q))hits.push(`💳 قسط: ${x.title}`)});
  alert(hits.length?hits.join("\n"):"ملقتش نتائج.");
};
window.openQuick=function(){
  const c=askValue("اختار: مصروف / حوّش / مهمة / عادة / هدف / تذكير");
  if(!c)return;
  const s=c.toLowerCase();
  if(s.includes("مصروف"))addExpense();
  else if(s.includes("حو"))addSaving();
  else if(s.includes("مهمة"))addTask();
  else if(s.includes("عادة"))addHabit();
  else if(s.includes("هدف"))addGoal();
  else addReminder();
};

window.addExpense=function(){
  const title=askValue("المصروف كان إيه؟","مواصلات");if(!title)return;
  const amount=num("المبلغ بالجنيه",50);if(amount===null)return;
  const cat=askValue("التصنيف","عام")||"عام";
  data.expenses.unshift({id:uid(),title,amount,cat,date:todayKey()});
  gainXP(5);save();notify("تم تسجيل المصروف 💸");
};
window.addSaving=function(){
  const amount=num("هتحوش كام؟",500);if(amount===null)return;
  const note=askValue("ملاحظة","ادخار");if(note===null)return;
  data.savings.unshift({id:uid(),amount,note,date:todayKey()});gainXP(8);save();notify("تم تسجيل التوفير 💰");
};
window.addTask=function(){
  const title=askValue("اسم المهمة");if(!title)return;
  const date=askValue("التاريخ YYYY-MM-DD",selectedDate)||selectedDate;
  data.tasks.push({id:uid(),title,date,done:false});gainXP(3);save();notify("تمت إضافة المهمة ✅");
};
window.toggleTask=function(id){const x=data.tasks.find(x=>x.id===id);if(!x)return;x.done=!x.done;if(x.done)gainXP(10);save()}
window.deleteTask=function(id){data.tasks=data.tasks.filter(x=>x.id!==id);save()}
window.addHabit=function(){
  const title=askValue("اسم العادة");if(!title)return;
  data.habits.push({id:uid(),title,doneDates:[],streak:0,best:0});save();notify("تمت إضافة العادة 🔥");
};
window.toggleHabit=function(id){
  const h=data.habits.find(x=>x.id===id);if(!h)return;
  const i=h.doneDates.indexOf(selectedDate);
  if(i>=0)h.doneDates.splice(i,1);else{h.doneDates.push(selectedDate);gainXP(12)}
  h.streak=calcStreak(h.doneDates);h.best=Math.max(h.best||0,h.streak);save();
};
window.addGoal=function(){
  const title=askValue("اسم الهدف");if(!title)return;
  const target=num("المبلغ المطلوب",10000);if(target===null)return;
  data.goals.push({id:uid(),title,target,current:0,deadline:""});save();notify("تم إنشاء الهدف 🎯");
};
window.addToGoal=function(id){
  const g=data.goals.find(x=>x.id===id);if(!g)return;
  const n=num("المبلغ الذي ستضيفه",500);if(n===null)return;
  g.current=Math.min(g.target,Number(g.current)+n);gainXP(15);save();notify("تقدم الهدف اتحدث 🎯");
};
window.addInstallment=function(){
  const title=askValue("اسم القسط");if(!title)return;
  const total=num("إجمالي القسط",2500);if(total===null)return;
  const paid=num("المدفوع حاليًا",0);if(paid===null)return;
  const due=askValue("موعد الاستحقاق YYYY-MM-DD","");if(due===null)return;
  data.installments.push({id:uid(),title,total,paid,due});save();notify("تمت إضافة القسط 💳");
};
window.payInstallment=function(id){
  const x=data.installments.find(x=>x.id===id);if(!x)return;
  const n=num("هتدفع كام؟",Math.max(0,x.total-x.paid));if(n===null)return;
  x.paid=Math.min(x.total,x.paid+n);gainXP(10);save();
};
window.addReminder=function(){
  const title=askValue("عنوان التذكير");if(!title)return;
  const when=askValue("موعد التذكير YYYY-MM-DD HH:MM","");if(!when)return;
  data.reminders.push({id:uid(),title,when,done:false});save();
  scheduleNativeReminder(data.reminders.at(-1));notify("تم حفظ التذكير 🔔");
};
window.completeReminder=function(id){const r=data.reminders.find(x=>x.id===id);if(r){r.done=true;save()}}
function scheduleNativeReminder(r){
  try{
    const ms=new Date(r.when.replace(" ","T")).getTime();
    if(window.ZokshAndroid&&Number.isFinite(ms))ZokshAndroid.scheduleReminder(Number(r.id),ms,r.title,"تذكير من يوميات الزوكش");
  }catch(e){}
}
function cancelNativeReminder(r){try{if(window.ZokshAndroid)ZokshAndroid.cancelReminder(Number(r.id))}catch(e){}}

window.saveFinance=function(){
  const income=Number($("incomeIn")?.value||data.finance.income);
  const fixed=Number($("fixedIn")?.value||data.finance.fixed);
  data.finance={income:income||0,fixed:fixed||0};save();notify("تم حفظ الميزانية 💰");
};
window.editName=function(){const n=askValue("اسمك",data.profile.name);if(n){data.profile.name=n;save()}}
window.toggleTheme=function(){data.theme=data.theme==="dark"?"light":"dark";save()}
window.backup=function(){
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="yawmeyat-elzoksh-backup.json";a.click();URL.revokeObjectURL(a.href);
};
window.restore=function(){
  const input=document.createElement("input");input.type="file";input.accept=".json";
  input.onchange=()=>{const f=input.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{data=Object.assign(structuredClone(defaults),JSON.parse(r.result));save();notify("تمت الاستعادة ♻️")}catch{alert("ملف النسخة الاحتياطية غير صالح.")}};r.readAsText(f)};
  input.click();
};
window.clearAll=function(){if(confirm("متأكد؟ هيتم مسح كل بياناتك.")){localStorage.removeItem(KEY);data=load();save();location.reload()}}
window.resetDemo=function(){
  data=structuredClone(defaults);
  data.finance={income:8000,fixed:3000};
  data.expenses=[{id:1,title:"مواصلات",amount:50,cat:"مواصلات",date:todayKey()},{id:2,title:"أكل",amount:120,cat:"أكل",date:todayKey()}];
  data.goals=[{id:2,title:"شراء Scooter",target:50000,current:12000,deadline:""}];
  data.tasks=[{id:3,title:"مذاكرة English",date:todayKey(),done:false},{id:4,title:"تسجيل المصاريف",date:todayKey(),done:true}];
  data.habits=[{id:5,title:"مذاكرة",doneDates:[todayKey()],streak:1,best:1}];
  data.installments=[{id:6,title:"قسط شهري",total:2500,paid:500,due:todayKey()}];
  save();notify("رجعنا بيانات تجريبية 🧪");
};

window.ask=function(q){$("msg").value=q;send()}
window.send=function(){
  const input=$("msg");const q=(input?.value||"").trim();if(!q)return;
  data.chat.push({w:"u",t:q});
  const a=assistant(q);
  data.chat.push({w:"b",t:a});input.value="";save();renderChat();
};
function assistant(q){
  const s=q.toLowerCase();
  let m;
  m=q.match(/(?:صرف|دفعت|دفعتل?ي)\s+(\d+(?:\.\d+)?)\s*(.*)/i);
  if(m){data.expenses.unshift({id:uid(),title:m[2]||"مصروف",amount:Number(m[1]),cat:m[2]||"عام",date:todayKey()});gainXP(5);return `تمام، سجلت ${money(Number(m[1]))} تحت ${esc(m[2]||"عام")} 💸`;}
  m=q.match(/(?:حوشت|حوش|وفرت|ادخرت)\s+(\d+(?:\.\d+)?)/i);
  if(m){data.savings.unshift({id:uid(),amount:Number(m[1]),note:"من المساعد",date:todayKey()});gainXP(8);return `تمام، سجلت توفير ${money(Number(m[1]))} 💰`;}
  m=q.match(/(?:مرتبي|دخلي|قبض(?:ت)?)\s*(\d+(?:\.\d+)?)/i);
  if(m){data.finance.income=Number(m[1]);return `سجلت دخلك ${money(m[1])}. المتاح بعد الثابت والمصروفات الحالية حوالي ${money(available())}.`;}
  m=q.match(/(?:هدف|حط هدف).*?(\d+(?:\.\d+)?)/i);
  if(m){const title=(q.replace(/(?:هدف|حط هدف)/i,"").replace(/\d+(?:\.\d+)?/,"").trim()||"هدف جديد");data.goals.push({id:uid(),title,target:Number(m[1]),current:0,deadline:""});return `عملت هدف «${esc(title)}» بقيمة ${money(m[1])} 🎯`;}
  if(s.includes("حلل")||s.includes("فلوسي")||s.includes("مالي"))return financeAdvice();
  if(s.includes("مهام"))return `عندك ${data.tasks.filter(x=>!x.done&&x.date===selectedDate).length} مهام مفتوحة النهارده.`;
  if(s.includes("هدف"))return data.goals.length?data.goals.map(g=>`🎯 ${g.title}: ${Math.round(g.current/g.target*100)}%`).join("\n"):"لسه مفيش أهداف.";
  if(s.includes("قسط"))return data.installments.length?data.installments.map(x=>`💳 ${x.title}: متبقي ${money(x.total-x.paid)} — ${x.due||"بدون موعد"}`).join("\n"):"مفيش أقساط مسجلة.";
  return "أقدر أسجل مصروف أو توفير أو دخل أو هدف، وأحلل فلوسك، وأعرض مهامك وأقساطك. مثال: «صرف 50 مواصلات».";
}
function financeAdvice(){
  const e=monthExpenses(), income=Number(data.finance.income)||0, fixed=Number(data.finance.fixed)||0, saved=data.savings.reduce((a,x)=>a+Number(x.amount),0);
  const avg=e/(new Date().getDate()||1), forecast=avg*new Date(new Date().getFullYear(),new Date().getMonth()+1,0).getDate();
  return `📊 تحليلك:\nالدخل: ${money(income)}\nالثابت: ${money(fixed)}\nمصروفات الشهر: ${money(e)}\nالتوفير المسجل: ${money(saved)}\nالمتاح التقريبي: ${money(available())}\nمتوسط الصرف اليومي: ${money(avg)}\nتوقع صرف الشهر: ${money(forecast)}.`;
}
function monthExpenses(){const ym=todayKey().slice(0,7);return data.expenses.filter(x=>x.date?.startsWith(ym)).reduce((a,x)=>a+Number(x.amount),0)}
function available(){return (Number(data.finance.income)||0)-(Number(data.finance.fixed)||0)-monthExpenses()}
function calcStreak(ds){let set=new Set(ds);let d=new Date();let n=0;while(set.has(todayKey(d))){n++;d.setDate(d.getDate()-1)}return n}
function gainXP(n){data.xp=(Number(data.xp)||0)+n}
function level(){return Math.floor(data.xp/100)+1}
function levelXP(){return data.xp%100}
function renderChat(){
  const el=$("chat");if(!el)return;
  el.innerHTML=(Array.isArray(data.chat)?data.chat:[]).map(m=>`<div class="msg ${m.w==="u"?"u":"b"}">${esc(m.t)}</div>`).join("");
  el.scrollTop=el.scrollHeight;
}
function renderHome(){
  $("dateText").textContent=new Intl.DateTimeFormat("ar-EG",{weekday:"long",year:"numeric",month:"long",day:"numeric"}).format(new Date());
  $("sFree").textContent=money(available());
  $("sSpend").textContent=money(data.expenses.filter(x=>x.date===todayKey()).reduce((a,x)=>a+Number(x.amount),0));
  $("sStreak").textContent=`${Math.max(0,...data.habits.map(x=>x.streak||0),0)} يوم`;
  $("sGoals").textContent=`${data.goals.filter(g=>g.current<g.target).length}/${data.goals.length}`;
  const ts=data.tasks.filter(x=>x.date===selectedDate).slice(0,4);
  $("homeTasks").innerHTML=ts.length?ts.map(t=>`<div class="item"><button class="check ${t.done?"done":""}" onclick="toggleTask(${t.id})">${t.done?"✓":""}</button><div class="grow">${esc(t.title)}<small>${t.done?"تم الإنجاز":"مفتوحة"}</small></div></div>`).join(""):"<p style='color:var(--muted)'>مفيش مهام لليوم.</p>";
  const g=data.goals.filter(x=>x.current<x.target).sort((a,b)=>b.current/b.target-a.current/a.target)[0];
  $("homeGoal").innerHTML=g?`<div class="item"><div class="grow"><b>${esc(g.title)}</b><small>${money(g.current)} من ${money(g.target)}</small><div class="line"><i style="width:${Math.min(100,g.current/g.target*100)}%"></i></div></div><button onclick="addToGoal(${g.id})">+</button></div>`:"<p style='color:var(--muted)'>أضف أول هدف ليظهر هنا.</p>";
}
function renderAchievements(){
  const xp=levelXP(),lv=level(),unlocked=Math.min(9,Math.floor(data.xp/50));
  $("levelBadge").textContent=`Lv. ${lv}`;$("xpText").textContent=`${xp} / 100 XP`;$("xpBar").style.width=`${xp}%`;
  $("levelTitle").textContent=lv<3?"بداية قوية":lv<6?"ماشي جامد":"زوكش محترف";
  $("nextLevelText").textContent=`${100-xp} XP للمستوى التالي`;
  $("achievementUnlocked").textContent=unlocked;$("achievementTotal").textContent=9;
  $("achievementStreak").textContent=Math.max(0,...data.habits.map(x=>x.best||0),0);
  const names=["أول خطوة","جامد","مواظب","مدير فلوس","موفر","صاحب أهداف","7 أيام","10 مهام","ZOKSH PRO"];
  $("achievementsGrid").innerHTML=names.map((n,i)=>`<div class="badge ${i<unlocked?"":"locked"}"><b>${i<unlocked?"🏆":"🔒"}</b><small>${n}</small></div>`).join("");
}
function renderMoney(){
  const e=monthExpenses(),income=Number(data.finance.income)||0,fixed=Number(data.finance.fixed)||0,saved=data.savings.reduce((a,x)=>a+Number(x.amount),0),commit=data.installments.reduce((a,x)=>a+Math.max(0,x.total-x.paid),0);
  $("mFree").textContent=money(available());$("mIncome").textContent=money(income);$("mSpend").textContent=money(e);$("mSaved").textContent=money(saved);$("mCommit").textContent=money(commit);
  $("incomeIn").value=income;$("fixedIn").value=fixed;
  $("financeKpis").innerHTML=`<div><small>الدخل</small><b>${money(income)}</b></div><div><small>الصرف</small><b>${money(e)}</b></div><div><small>المتاح</small><b>${money(available())}</b></div>`;
  const cats={};data.expenses.filter(x=>x.date?.startsWith(todayKey().slice(0,7))).forEach(x=>cats[x.cat]=(cats[x.cat]||0)+Number(x.amount));
  const total=e||1, entries=Object.entries(cats).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const colors=["#9b5cff","#52df9b","#ff6f91","#e6bd62","#64b5f6"];let acc=0,grad=[];
  entries.forEach(([,v],i)=>{const p=v/total*100;grad.push(`${colors[i]} ${acc}% ${acc+p}%`);acc+=p});
  $("categoryDonut").style.background=`conic-gradient(${grad.join(",")||"#352a40 0 100%"})`;
  $("categoryLegend").innerHTML=entries.map((x,i)=>`<div class="legend"><span>${esc(x[0])}</span><b>${money(x[1])}</b></div>`).join("")||"لا توجد مصروفات";
  $("incomeExpenseChart").innerHTML=`<div class="barcol" style="height:${Math.min(100,Math.max(4,income/(Math.max(income,e)||1)*100))}%"><span>الدخل</span></div><div class="barcol alt" style="height:${Math.min(100,Math.max(4,e/(Math.max(income,e)||1)*100))}%"><span>المصروف</span></div>`;
  const days=new Date().getDate(), avg=e/(days||1), endDays=new Date(new Date().getFullYear(),new Date().getMonth()+1,0).getDate(), forecast=avg*endDays;
  $("forecast").innerHTML=`<div class="item"><div class="grow"><b>التوقع</b><small>لو استمر متوسط صرفك الحالي</small></div><strong>${money(forecast)}</strong></div>`;
  $("forecastLineHint").textContent=`متوسط يومي ${money(avg)}`;
  $("forecastLineChart").innerHTML=Array.from({length:12},(_,i)=>`<i style="height:${Math.max(5,Math.min(100,(i+1)*forecast/12/(income||1)*100))}%"></i>`).join("");
  $("availableValue").textContent=money(available());$("availableRatio").textContent=`${income?Math.round(Math.max(0,available())/income*100):0}%`;$("availableStatus").textContent=available()>=0?"أنت تمام 👍":"محتاج تقلل الصرف ⚠️";
  $("availableFill").style.width=`${Math.min(100,Math.max(0,income?available()/income*100:0))}%`;
  $("bars").innerHTML=Array.from({length:Math.min(14,endDays)},(_,i)=>{const d=String(i+1).padStart(2,"0"),v=data.expenses.filter(x=>x.date===`${todayKey().slice(0,7)}-${d}`).reduce((a,x)=>a+Number(x.amount),0);return `<i title="${v} ج" style="height:${Math.max(2,Math.min(100,v/Math.max(1,e)*100*5))}%"></i>`}).join("");
  $("goals").innerHTML=data.goals.length?data.goals.map(g=>`<div class="item"><div class="grow"><b>${esc(g.title)}</b><small>${money(g.current)} / ${money(g.target)}</small><div class="line"><i style="width:${Math.min(100,g.current/g.target*100)}%"></i></div></div><button onclick="addToGoal(${g.id})">+</button></div>`).join(""):"<p style='color:var(--muted)'>مفيش أهداف.</p>";
  $("installments").innerHTML=data.installments.length?data.installments.map(x=>`<div class="item"><div class="grow"><b>${esc(x.title)}</b><small>متبقي ${money(x.total-x.paid)} • ${esc(x.due||"بدون موعد")}</small></div><button onclick="payInstallment(${x.id})">دفع</button></div>`).join(""):"<p style='color:var(--muted)'>مفيش أقساط.</p>";
  $("expenses").innerHTML=data.expenses.slice(0,10).map(x=>`<div class="item"><div class="grow"><b>${esc(x.title)}</b><small>${esc(x.cat)} • ${x.date}</small></div><strong>${money(x.amount)}</strong></div>`).join("")||"<p style='color:var(--muted)'>مفيش مصاريف.</p>";
}
function renderDay(){
  const y=calendarDate.getFullYear(),m=calendarDate.getMonth(),first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate();
  $("monthTitle").textContent=new Intl.DateTimeFormat("ar-EG",{month:"long",year:"numeric"}).format(calendarDate);
  const cells=[];for(let i=0;i<first;i++)cells.push(`<div class="day empty"></div>`);
  for(let d=1;d<=days;d++){const k=`${y}-${String(m+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`,has=data.tasks.some(x=>x.date===k)||data.reminders.some(x=>x.when?.startsWith(k));cells.push(`<button class="day ${k===selectedDate?"sel":""} ${has?"has":""}" onclick="selectDate('${k}')">${d}</button>`)}
  $("cal").innerHTML=cells.join("");
  const ts=data.tasks.filter(x=>x.date===selectedDate),done=ts.filter(x=>x.done).length,pct=ts.length?Math.round(done/ts.length*100):0;
  $("selLabel").textContent=new Intl.DateTimeFormat("ar-EG",{weekday:"long",month:"long",day:"numeric"}).format(new Date(selectedDate+"T12:00"));
  $("selPct").textContent=`${done}/${ts.length} • ${pct}%`;
  $("selBar").style.width=pct+"%";
  $("tasks").innerHTML=ts.length?ts.map(t=>`<div class="item"><button class="check ${t.done?"done":""}" onclick="toggleTask(${t.id})">${t.done?"✓":""}</button><div class="grow"><b>${esc(t.title)}</b><small>${t.done?"مكتملة":"مفتوحة"}</small></div><button onclick="deleteTask(${t.id})">🗑</button></div>`).join(""):"<p style='color:var(--muted)'>مفيش مهام في اليوم ده.</p>";
  $("habits").innerHTML=data.habits.length?data.habits.map(h=>`<div class="item"><button class="check ${h.doneDates.includes(selectedDate)?"done":""}" onclick="toggleHabit(${h.id})">${h.doneDates.includes(selectedDate)?"✓":""}</button><div class="grow"><b>${esc(h.title)}</b><small>🔥 ${h.streak} يوم • أفضل ${h.best}</small></div></div>`).join(""):"<p style='color:var(--muted)'>أضف عادة وابدأ الـStreak.</p>";
  $("reminders").innerHTML=data.reminders.length?data.reminders.map(r=>`<div class="item"><div class="grow"><b>${esc(r.title)}</b><small>${esc(r.when)}</small></div><button onclick="completeReminder(${r.id})">${r.done?"✓":"تم"}</button></div>`).join(""):"<p style='color:var(--muted)'>مفيش تذكيرات.</p>";
}
window.selectDate=function(k){selectedDate=k;renderDay()}
window.moveMonth=function(n){calendarDate.setMonth(calendarDate.getMonth()+n);renderDay()}
function renderSettings(){$("profileName").textContent=data.profile.name||"زوكش";document.body.classList.toggle("light",data.theme==="light")}
function renderAll(){
  renderHome();renderAchievements();renderMoney();renderDay();renderSettings();renderChat();
  const active=document.querySelector(".page.active");document.querySelectorAll(".nav button[data-p]").forEach(b=>b.classList.toggle("active",b.dataset.p===active?.id));
}
function onboarding(){
  if(data.onboarded)return;
  const name=askValue("أهلاً بيك في يوميات الزوكش ❤️ اسمك إيه؟","زوكش");
  if(name)data.profile.name=name;
  const income=num("دخلك الشهري تقريبًا؟",data.finance.income);if(income!==null)data.finance.income=income;
  const fixed=num("التزاماتك الثابتة شهريًا؟",data.finance.fixed);if(fixed!==null)data.finance.fixed=fixed;
  data.onboarded=true;save();
}
window.addEventListener("DOMContentLoaded",()=>{onboarding();renderAll();});
window.addEventListener("keydown",e=>{if(e.key==="Enter"&&document.activeElement?.id==="msg")send()});
})();
