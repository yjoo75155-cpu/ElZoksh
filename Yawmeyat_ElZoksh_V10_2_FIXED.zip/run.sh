#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
echo "يوميات الزوكش V10 -> http://127.0.0.1:8093"
python -m http.server 8093 --bind 127.0.0.1
