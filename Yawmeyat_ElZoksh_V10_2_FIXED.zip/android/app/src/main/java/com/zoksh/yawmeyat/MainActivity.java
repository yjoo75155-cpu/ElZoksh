package com.zoksh.yawmeyat;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.View;
import android.graphics.Color;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(18,13,31));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.addJavascriptInterface(new AndroidBridge(), "ZokshAndroid");
        web.loadUrl("file:///android_asset/www/index.html");

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 100);
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void scheduleReminder(int id, long timeMs, String title, String text) {
            ReminderScheduler.schedule(MainActivity.this, id, timeMs, title, text);
        }
        @JavascriptInterface public void cancelReminder(int id) {
            ReminderScheduler.cancel(MainActivity.this, id);
        }
        @JavascriptInterface public void saveReminders(String json) {
            getSharedPreferences(ReminderScheduler.PREF, MODE_PRIVATE).edit().putString("items", json).apply();
        }
        @JavascriptInterface public void requestExactAlarmPermission() {
            if (Build.VERSION.SDK_INT >= 31) {
                try {
                    Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch(Exception ignored) {}
            }
        }
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
