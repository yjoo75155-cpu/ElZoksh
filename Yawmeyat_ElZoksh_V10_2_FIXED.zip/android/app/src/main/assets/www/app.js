const KEY="zoksh_v8";const today=()=>new Date().toISOString().slice(0,10);const money=n=>Number(n||0).toLocaleString("ar-EG")+" ج";const $=id=>document.getElementById(id);const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));const uid=()=>Date.now()+Math.floor(Math.random()*999);
function demo(){return {name:"زوكش",income:8500,fixed:1000,saved:1500,expenses:[{id:1,name:"أكل",amount:1200,date:"2026-09-02"},{id:2,name:"مواصلات",amount:550,date:"2026-09-05"},{id:3,name:"سكن",amount:1000,date:"2026-09-07"},{id:4,name:"مصاريف شخصية",amount:400,date:"2026-09-09"},{id:5,name:"ترفيه",amount:300,date:"2026-09-10"},{id:6,name:"مواصلات",amount:120,date:"2026-09-11"}],tasks:[{id:11,name:"مذاكرة إنجليزي",date:"2026-09-11",done:true},{id:12,name:"مراجعة المصاريف",date:"2026-09-11",done:true},{id:13,name:"رياضة",date:"2026-09-11",done:false},{id:14,name:"قراءة 20 صفحة",date:"2026-09-11",done:false},{id:15,name:"التواصل مع العمل",date:"2026-09-11",done:false}],habits:[{id:21,name:"شرب مياه",icon:"💧"},{id:22,name:"مذاكرة",icon:"📚"},{id:23,name:"رياضة",icon:"🏃"},{id:24,name:"نوم بدري",icon:"😴"}],habitLogs:{},goals:[{id:31,name:"لابتوب جديد",target:10000,current:6000,deadline:"2026-10-20"},{id:32,name:"السفر",target:20000,current:6000,deadline:"2026-12-15"},{id:33,name:"تطوير الذات",target:1000,current:800,deadline:"2026-10-01"}],installments:[{id:41,name:"قسط الموبايل",amount:250,count:3,paid:1,due:"2026-09-15"},{id:42,name:"قسط الدراجة",amount:300,count:5,paid:2,due:"2026-09-18"}],reminders:[{id:51,name:"مراجعة المصاريف",time:"21:00",date:"2026-09-11"}],chat:[{w:"b",t:"أهلاً يا زوكش 👋<br>أنا المساعد بتاعك. جرّب أي أمر من الأزرار أو اكتبلي بطريقتك."}]}}
let data=JSON.parse(localStorage.getItem(KEY)||"null")||demo();let selected=today(),view=new Date(selected+"T12:00:00");function save(){localStorage.setItem(KEY,JSON.stringify(data));render();renderChat()}function go(p){document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x.id===p));document.querySelectorAll(".nav button[data-p]").forEach(x=>x.classList.toggle("active",x.dataset.p===p));render();renderChat();scrollTo(0,0)}function modal(t,b){$("mt").textContent=t;$("mb").innerHTML=b;$("modal").classList.add("show")}function closeModal(){$("modal").classList.remove("show")}function actions(fn){return `<div class="actions"><button class="save" onclick="${fn}">حفظ</button><button class="cancel" onclick="closeModal()">إلغاء</button></div>`}
function addExpense(){modal("💸 تسجيل مصروف",`<input id="x1" placeholder="مثال: مواصلات"><input id="x2" type="number" placeholder="المبلغ"><label>التاريخ</label><input id="x3" type="date" value="${selected}">${actions("saveExpense()")}`)}function saveExpense(){let n=$("x1").value.trim(),a=+$("x2").value,dt=$("x3").value||selected;if(!n||a<=0)return alert("اكتب النوع والمبلغ");data.expenses.unshift({id:uid(),name:n,amount:a,date:dt});closeModal();save()}
function addSaving(){modal("💰 تحويش",`<input id="x1" type="number" placeholder="المبلغ">${actions("saveSaving()")}`)}function saveSaving(){let n=+$("x1").value;if(n<=0)return;data.saved+=n;closeModal();save()}
function addTask(){modal("✅ مهمة جديدة",`<input id="x1" placeholder="اسم المهمة"><label>اليوم</label><input id="x2" type="date" value="${selected}">${actions("saveTask()")}`)}function saveTask(){let n=$("x1").value.trim(),dt=$("x2").value||selected;if(!n)return;data.tasks.unshift({id:uid(),name:n,date:dt,done:false});closeModal();save()}
function addHabit(){modal("🔥 عادة جديدة",`<input id="x1" placeholder="اسم العادة"><input id="x2" value="🔥" placeholder="أيقونة">${actions("saveHabit()")}`)}function saveHabit(){let n=$("x1").value.trim(),ic=$("x2").value||"🔥";if(!n)return;data.habits.push({id:uid(),name:n,icon:ic});closeModal();save()}
function toggleTask(id){let x=data.tasks.find(t=>t.id===id);if(x)x.done=!x.done;save()}function toggleHabit(id){let k=id+"_"+selected;data.habitLogs[k]=!data.habitLogs[k];save()}
function streak(id){let n=0,t=new Date();while(1){let k=id+"_"+t.toISOString().slice(0,10);if(!data.habitLogs[k])break;n++;t.setDate(t.getDate()-1)}return n}
function bestStreak(id){let dates=Object.keys(data.habitLogs).filter(k=>k.startsWith(id+"_")&&data.habitLogs[k]).map(k=>k.slice(String(id).length+1)).sort();let best=0,run=0,prev=null;for(const z of dates){let a=new Date(z),b=prev?new Date(prev):null;if(!b||Math.round((a-b)/864e5)!==1)run=1;else run++;best=Math.max(best,run);prev=z}return best}
function addGoal(){modal("🎯 هدف جديد",`<input id="x1" placeholder="اسم الهدف"><input id="x2" type="number" placeholder="المبلغ المستهدف"><input id="x3" type="number" value="0" placeholder="المبلغ الحالي"><label>الموعد النهائي</label><input id="x4" type="date" value="${new Date(Date.now()+30*864e5).toISOString().slice(0,10)}">${actions("saveGoal()")}`)}function saveGoal(){let n=$("x1").value.trim(),t=+$("x2").value,c=+$("x3").value||0,dl=$("x4").value;if(!n||t<=0||!dl)return;data.goals.push({id:uid(),name:n,target:t,current:c,deadline:dl});closeModal();save()}
function updateGoal(id){let g=data.goals.find(x=>x.id===id);modal("🎯 تحديث "+esc(g.name),`<input id="x1" type="number" value="${g.current}" placeholder="المبلغ الحالي">${actions("saveGoalUpdate("+id+")")}`)}function saveGoalUpdate(id){data.goals.find(x=>x.id===id).current=+$("x1").value||0;closeModal();save()}
function addInstallment(){modal("📌 قسط جديد",`<input id="x1" placeholder="اسم الالتزام"><input id="x2" type="number" placeholder="قيمة الدفعة"><input id="x3" type="number" value="1" placeholder="عدد الدفعات"><label>أول استحقاق</label><input id="x4" type="date" value="${selected}">${actions("saveInstallment()")}`)}function saveInstallment(){let n=$("x1").value.trim(),a=+$("x2").value,c=Math.max(1,+$("x3").value||1),dt=$("x4").value;if(!n||a<=0)return;data.installments.push({id:uid(),name:n,amount:a,count:c,paid:0,due:dt});closeModal();save()}function payInstallment(id){let x=data.installments.find(i=>i.id===id);if(x)x.paid=Math.min(x.count,x.paid+1);save()}
function addReminder(){modal("🔔 تذكير",`<input id="x1" placeholder="التذكير"><input id="x2" type="time" value="21:00"><label>التاريخ</label><input id="x3" type="date" value="${selected}">${actions("saveReminder()")}`)}function saveReminder(){let n=$("x1").value.trim(),tm=$("x2").value,dt=$("x3").value||selected;if(!n)return;data.reminders.push({id:uid(),name:n,time:tm,date:dt});closeModal();save()}
function saveFinance(){data.income=+$("incomeIn").value||0;data.fixed=+$("fixedIn").value||0;save();alert("تم حفظ الميزانية 💜")}function editName(){let n=prompt("اسمك",data.name);if(n){data.name=n;save()}}
function backup(){let a=document.createElement("a"),b=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});a.href=URL.createObjectURL(b);a.download="zoksh-v8-backup.json";a.click()}
function restore(){let i=document.createElement("input");i.type="file";i.accept=".json";i.onchange=()=>{let r=new FileReader();r.onload=()=>{try{data=JSON.parse(r.result);save();alert("تم الاسترجاع")}catch{alert("النسخة غير صالحة")}};r.readAsText(i.files[0])};i.click()}
function resetDemo(){if(confirm("إرجاع البيانات التجريبية؟")){data=demo();save()}}function clearAll(){if(confirm("مسح كل البيانات؟")){data={...demo(),income:0,fixed:0,saved:0,expenses:[],tasks:[],habits:[],habitLogs:{},goals:[],installments:[],reminders:[],chat:[]};save()}}
function openSearch(){modal("🔎 البحث في كل البيانات",`<input id="searchInput" oninput="searchAll()" placeholder="مواصلات، مذاكرة، 2500..."><div id="searchOut"></div>`);setTimeout(()=>$("searchInput").focus(),80)}
function searchAll(){let q=($("searchInput")?.value||"").toLowerCase().trim(),all=[];data.expenses.forEach(x=>all.push(["💸 مصروف",x.name,money(x.amount)+" • "+x.date]));data.tasks.forEach(x=>all.push(["✅ مهمة",x.name,x.date]));data.habits.forEach(x=>all.push(["🔥 عادة",x.name,"Streak "+streak(x.id)]));data.goals.forEach(x=>all.push(["🎯 هدف",x.name,money(x.current)+"/"+money(x.target)+" • "+x.deadline]));data.installments.forEach(x=>all.push(["📌 قسط",x.name,money(x.amount)+" • "+x.due]));data.reminders.forEach(x=>all.push(["🔔 تذكير",x.name,x.date+" "+x.time]));let r=all.filter(x=>(x[0]+" "+x[1]+" "+x[2]).toLowerCase().includes(q));$("searchOut").innerHTML=q?(r.length?r.map(x=>`<div class="searchRes"><b>${x[0]}</b> ${esc(x[1])}<small>${esc(x[2])}</small></div>`).join(""):'<div class="empty">مفيش نتائج.</div>'):""}
function openQuick(){modal("＋ إضافة سريعة",`<div class="quick">${["addExpense()","addSaving()","addTask()","addHabit()"].map((f,i)=>`<button onclick="closeModal();setTimeout(()=>${f},80)">${["💸 مصروف","💰 تحويش","✅ مهمة","🔥 عادة"][i]}</button>`).join("")}</div>`)}
function moveMonth(n){view.setMonth(view.getMonth()+n);renderCalendar()}function pickDate(x){selected=x;view=new Date(x+"T12:00:00");render()}
function renderCalendar(){let y=view.getFullYear(),m=view.getMonth(),first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate();$("monthTitle").textContent=new Date(y,m,1).toLocaleDateString("ar-EG",{month:"long",year:"numeric"});let h="";for(let i=0;i<first;i++)h+="<div></div>";for(let n=1;n<=days;n++){let dt=`${y}-${String(m+1).padStart(2,"0")}-${String(n).padStart(2,"0")}`,has=data.tasks.some(x=>x.date===dt)||data.expenses.some(x=>x.date===dt);h+=`<button class="calday ${dt===selected?"sel":""} ${dt===today()?"today":""}" onclick="pickDate('${dt}')"><b>${n}</b>${has?'<div class="dot">●</div>':""}</button>`}$("cal").innerHTML=h}

function monthForecast(){
  const now=dateObj(selected), y=now.getFullYear(), m=now.getMonth();
  const daysInMonth=new Date(y,m+1,0).getDate();
  const day=Math.max(1,now.getDate());
  const monthPrefix=selected.slice(0,7);
  const monthExpenses=data.expenses.filter(x=>x.date.startsWith(monthPrefix));
  const spent=sumExpenses(monthExpenses);
  const avg=spent/day;
  const projected=Math.round(avg*daysInMonth);
  const availableProjected=data.income-data.fixed-projected;
  const remainingDays=Math.max(0,daysInMonth-day);
  const dailyLimit=remainingDays>0?Math.max(0,Math.floor((data.income-data.fixed-spent)/remainingDays)):0;
  const goal=goalStats();
  return {daysInMonth,day,spent,avg,projected,availableProjected,remainingDays,dailyLimit,goal};
}
function renderForecast(){
  const f=monthForecast();
  const tone=f.availableProjected<0?"alertWarn":"alertGood";
  const text=f.availableProjected<0
    ?`⚠️ بالمعدل الحالي، متوقع المصاريف توصل ${money(f.projected)} آخر الشهر، وده ممكن يعمل عجز حوالي ${money(Math.abs(f.availableProjected))}.`
    :`✨ بالمعدل الحالي، متوقع تخلص الشهر بمصاريف حوالي ${money(f.projected)}، والمتاح المتوقع ${money(f.availableProjected)}.`;
  $("forecast").innerHTML=`<div class="alertBox ${tone}"><strong>🔮 التوقع لنهاية الشهر</strong>${text}</div><div class="forecastGrid"><div><small>متوسط الصرف اليومي</small><b>${money(Math.round(f.avg))}</b></div><div><small>حد الصرف اليومي المقترح</small><b>${money(f.dailyLimit)}</b></div><div><small>المصاريف المتوقعة</small><b>${money(f.projected)}</b></div><div><small>تقدم الأهداف</small><b>${f.goal.avg}%</b></div></div><div class="forecastNote">التوقع مبني على مصاريف الشهر المسجلة حتى ${f.day} من ${f.daysInMonth} يوم، ويتحدث تلقائيًا مع كل مصروف جديد.</div>`;
}
function renderMoneyAlert(){
  const f=monthForecast(), freeNow=data.income-data.fixed-f.spent, threshold=Math.max(500,data.income*.15);
  let html="";
  if(data.income>0 && freeNow<=0) html=`<div class="alertBox alertWarn"><strong>🚨 المتاح خلص</strong>أنت حاليًا عند ${money(freeNow)} بعد مصاريف الشهر. خفّف المصروف قبل أي التزام جديد.</div>`;
  else if(data.income>0 && freeNow<=threshold) html=`<div class="alertBox alertWarn"><strong>⚠️ المتاح قرب يقل</strong>فاضلك ${money(freeNow)} فقط. حاول تخلي المصروف اليومي في حدود ${money(f.dailyLimit)}.</div>`;
  else if(data.income>0) html=`<div class="alertBox alertGood"><strong>💚 وضعك مطمّن</strong>المتاح حاليًا ${money(freeNow)}، والتوقع لنهاية الشهر ${money(f.availableProjected)}.</div>`;
  $("moneyAlert").innerHTML=html;
}

function financeCategory(name){
  const n=String(name||"").toLowerCase();
  if(/أكل|اكل|مطعم|كافيه|قهوة|غدا|عشا|فطار|food|restaurant|coffee/.test(n)) return ["🍔","أكل"];
  if(/مواصل|تاكس|اوبر|أوبر|مترو|بنزين|transport|uber|taxi|metro|fuel/.test(n)) return ["🚕","مواصلات"];
  if(/سكن|إيجار|ايجار|بيت|كهرب|مياه|غاز|rent|home|utilities/.test(n)) return ["🏠","سكن وفواتير"];
  if(/ترفيه|سينما|خرو|لعب|game|entertain|movie/.test(n)) return ["🎮","ترفيه"];
  if(/تعليم|كورس|كتاب|مذاكر|education|course|book/.test(n)) return ["📚","تعليم"];
  if(/صحة|دكتور|دواء|صيدلي|health|doctor|pharmacy/.test(n)) return ["💊","صحة"];
  if(/شخص|ملابس|جزمة|هدوم|personal|clothes/.test(n)) return ["🛍️","شخصي"];
  return ["📦","أخرى"];
}
function polarPoint(cx,cy,r,deg){const a=(deg-90)*Math.PI/180;return [cx+r*Math.cos(a),cy+r*Math.sin(a)]}
function donutArc(cx,cy,r1,r2,start,end){
 const [x1,y1]=polarPoint(cx,cy,r2,start),[x2,y2]=polarPoint(cx,cy,r2,end),[x3,y3]=polarPoint(cx,cy,r1,end),[x4,y4]=polarPoint(cx,cy,r1,start);
 const large=end-start>180?1:0; return `M ${x1} ${y1} A ${r2} ${r2} 0 ${large} 1 ${x2} ${y2} L ${x3} ${y3} A ${r1} ${r1} 0 ${large} 0 ${x4} ${y4} Z`;
}
function renderFinanceDashboard(month){
 const expenses=data.expenses.filter(x=>x.date.startsWith(month)),total=expenses.reduce((a,x)=>a+Number(x.amount||0),0);
 const now=dateObj(selected),day=Math.max(1,Number(selected.slice(-2))),daysInMonth=new Date(now.getFullYear(),now.getMonth()+1,0).getDate();
 const avg=total/day,projected=Math.round(avg*daysInMonth),rawAvailable=Number(data.income||0)-Number(data.fixed||0)-total;
 const commitments=data.installments.reduce((a,x)=>a+Math.max(0,Number(x.amount||0)*(Number(x.count||0)-Number(x.paid||0))),0);
 const effective=Math.max(0,rawAvailable-commitments),budget=Math.max(1,Number(data.income||0)-Number(data.fixed||0));
 const pct=Math.max(0,Math.min(100,(rawAvailable/budget)*100)),ratio=data.income?Math.round(total/data.income*100):0;
 const groups={}; expenses.forEach(x=>{const [icon,label]=financeCategory(x.name);if(!groups[label])groups[label]={icon,total:0};groups[label].total+=Number(x.amount||0)});
 const cats=Object.entries(groups).sort((a,b)=>b[1].total-a[1].total).slice(0,7),series=["#b46cff","#6dd6ff","#55dfb4","#ffb85c","#ff7f9e","#a6a0ff","#8f98a8"];
 const donut=$("categoryDonut"),legend=$("categoryLegend");
 if(cats.length){
   let start=0,paths="";
   cats.forEach(([label,v],i)=>{const sweep=total?(v.total/total)*359.8:0;paths+=`<path d="${donutArc(70,70,40,62,start,start+sweep)}" fill="${series[i%series.length]}" data-cat="${esc(label)}" class="donutSeg" tabindex="0"></path>`;start+=sweep});
   donut.innerHTML=`<svg viewBox="0 0 140 140" role="img" aria-label="المصاريف حسب التصنيف">${paths}<circle cx="70" cy="70" r="38" fill="none" stroke="var(--panel)" stroke-width="3"/><text x="70" y="66" text-anchor="middle" class="donutTotal">${Math.round(total).toLocaleString("ar-EG")}</text><text x="70" y="80" text-anchor="middle" class="donutLabel">إجمالي المصروف</text></svg>`;
   legend.innerHTML=cats.map(([label,v],i)=>`<button type="button" class="catItem" data-cat="${esc(label)}"><i style="background:${series[i%series.length]}"></i><span>${v.icon} ${esc(label)}</span><b>${money(v.total)}</b></button>`).join("");
   const selectCat=label=>{const row=cats.find(x=>x[0]===label);if(row)$("catHint").textContent=`${row[1].icon} ${label}: ${money(row[1].total)}`};
   document.querySelectorAll(".catItem,.donutSeg").forEach(el=>el.addEventListener("click",()=>selectCat(el.dataset.cat)));
 }else{donut.innerHTML='<div class="empty">لسه مفيش مصاريف.</div>';legend.innerHTML=""}
 $("financeKpis").innerHTML=[["💵","الدخل",money(data.income)],["💸","المصروف",money(total)],["🧾","المتاح",money(rawAvailable)],["📌","بعد الالتزامات",money(effective)]].map(k=>`<div><span>${k[0]}</span><small>${k[1]}</small><b>${k[2]}</b></div>`).join("");
 const inc=Math.max(0,Number(data.income||0)),maxIE=Math.max(1,inc,total);
 $("incomeExpenseChart").innerHTML=`<div class="ieBars"><div class="ieCol"><div class="ieValue">${money(inc)}</div><i style="height:${Math.max(6,inc/maxIE*100)}%"></i><small>الدخل</small></div><div class="ieCol"><div class="ieValue">${money(total)}</div><i style="height:${Math.max(6,total/maxIE*100)}%"></i><small>المصروف</small></div></div><div class="compareNote">${ratio}% من الدخل اتصرف${rawAvailable<0?" — الميزانية متجاوزة":""}</div>`;
 const points=7,w=420,h=150,pad=24,maxY=Math.max(1,total,projected,budget),vals=[];
 for(let i=0;i<points;i++){const d=Math.max(1,Math.round(day/(points-1)*i));vals.push(Math.round(avg*d))} vals[points-1]=projected;
 const pts=vals.map((v,i)=>`${pad+i*((w-pad*2)/(points-1))},${h-pad-(v/maxY)*(h-pad*2)}`).join(" "),budgetY=h-pad-(Math.min(maxY,budget)/maxY)*(h-pad*2);
 $("forecastLineChart").innerHTML=`<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" role="img" aria-label="توقع المصروف حتى نهاية الشهر"><line x1="${pad}" y1="${budgetY}" x2="${w-pad}" y2="${budgetY}" stroke="#6f647b" stroke-dasharray="5 5"/><polyline points="${pts}" fill="none" stroke="#b46cff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${w-pad}" cy="${h-pad-(projected/maxY)*(h-pad*2)}" r="5" fill="#55dfb4"/><text x="${w-pad}" y="${Math.max(14,h-pad-(projected/maxY)*(h-pad*2)-10)}" text-anchor="end" fill="#e8e1ed" font-size="11">${projected.toLocaleString("ar-EG")} ج متوقع</text><text x="${w-pad}" y="${Math.max(14,budgetY-7)}" text-anchor="end" fill="#92899b" font-size="9">حد الدخل</text></svg>`;
 $("forecastLineHint").textContent=`متوسط ${money(Math.round(avg))} يوميًا • متوقع ${money(projected)}`;
 $("availableFill").style.width=pct+"%";$("availableNeedle").style.left=pct+"%";$("availableValue").textContent=money(rawAvailable);$("availableRatio").textContent=Math.round(pct)+"% من المتاح القابل للصرف";$("availableStatus").textContent=rawAvailable<0?"متجاوز الميزانية":rawAvailable<budget*.15?"متاح منخفض":"الوضع آمن";$("availableStatus").className=rawAvailable<0?"bad":rawAvailable<budget*.15?"warn":"good";
}


function renderSmartHighlights(){
  const month=selected.slice(0,7), expenses=data.expenses.filter(x=>x.date.startsWith(month));
  const spent=expenses.reduce((a,x)=>a+Number(x.amount||0),0), income=Number(data.income||0), fixed=Number(data.fixed||0);
  const available=income-fixed-spent, ratio=income?spent/income:0;
  const goals=data.goals||[], goal=goals.slice().sort((a,b)=>Number(b.progress||0)-Number(a.progress||0))[0];
  const h=income<=0?50:Math.max(0,Math.min(100,Math.round((available/Math.max(1,income-fixed))*70+(1-ratio)*30)));
  const scoreText=h>=80?"ممتاز جدًا 💚":h>=60?"كويس جدًا 👍":h>=40?"محتاج تركيز 👀":"خطر — راجع مصاريفك 🚨";
  const one=$("highlight1"),two=$("highlight2"),three=$("highlight3");
  if(one) one.textContent=spent===0?"لسه مفيش مصاريف":`صرفك ${money(spent)} • ${Math.round(ratio*100)}% من الدخل`;
  if(two) two.textContent=goal?`${goal.name} • ${Math.round(Number(goal.current||0)/Math.max(1,Number(goal.target||0))*100)}%`:"أضف هدفًا وابدأ التقدم";
  if(three) three.textContent=`${scoreText} • ${h}/100`;
}


// ===== ZOKSH ACHIEVEMENTS & LEVELS =====
const ACHIEVEMENTS = [
  {id:"budget_3", icon:"🎯", name:"على الميزانية", desc:"حافظ على المتاح بدون تجاوز الميزانية", xp:30, goal:3, type:"budget"},
  {id:"save_1000", icon:"💰", name:"أول ألف توفير", desc:"وصل إجمالي التوفير إلى 1,000 جنيه", xp:35, goal:1000, type:"saving"},
  {id:"save_3000", icon:"🏦", name:"جامع التوفير", desc:"وصل إجمالي التوفير إلى 3,000 جنيه", xp:55, goal:3000, type:"saving"},
  {id:"expenses_7", icon:"🧾", name:"دفتر الحسابات", desc:"سجّل مصاريف في 7 أيام مختلفة", xp:45, goal:7, type:"logging"},
  {id:"expenses_30", icon:"📚", name:"محاسب محترف", desc:"سجّل مصاريف في 30 يومًا مختلفة", xp:80, goal:30, type:"logging"},
  {id:"goal_1", icon:"🏁", name:"أول هدف", desc:"حقق هدفًا ماليًا كاملًا", xp:60, goal:1, type:"goal"},
  {id:"goal_50", icon:"🚀", name:"نص الطريق", desc:"وصل أحد أهدافك إلى 50%", xp:35, goal:50, type:"goal50"},
  {id:"streak_7", icon:"🔥", name:"أسبوع ملتزم", desc:"التزم بالميزانية 7 أيام متتالية", xp:70, goal:7, type:"streak"},
  {id:"streak_30", icon:"👑", name:"ملك الالتزام", desc:"التزم بالميزانية 30 يومًا متتالية", xp:140, goal:30, type:"streak"}
];

function getAchData(){
  const raw = localStorage.getItem("zoksh_achievements");
  try { return raw ? JSON.parse(raw) : {budgetDays:[], loggedDays:[], budgetStreak:0, bestStreak:0}; }
  catch(e){ return {budgetDays:[], loggedDays:[], budgetStreak:0, bestStreak:0}; }
}
function saveAchData(d){ localStorage.setItem("zoksh_achievements", JSON.stringify(d)); }
function dayKey(d=new Date()){ return d.toISOString().slice(0,10); }
function achievementMetrics(){
  const d=getAchData();
  const expenses = Array.isArray(data.expenses) ? data.expenses : [];
  const totalSaved = Number(data.saved||0);
  const goals = Array.isArray(data.goals) ? data.goals : [];
  const completedGoals = goals.filter(g => Number(g.target||0)>0 && Number(g.current||0)>=Number(g.target||0)).length;
  const maxGoalPct = goals.length ? Math.max(...goals.map(g=>Math.min(100,Math.round(Number(g.current||0)/Math.max(1,Number(g.target||0))*100)))) : 0;
  const today = dayKey();
  const todayExpenses = expenses.filter(e => String(e.date||"").slice(0,10)===today).reduce((s,e)=>s+Number(e.amount||0),0);
  const income = Number(data.income||0);
  const fixed = Number(data.fixed||0);
  const available = income-fixed-todayExpenses;
  // A day counts as budget-safe if it has no expense overrun relative to a simple daily allowance.
  const daysInMonth = new Date(new Date().getFullYear(),new Date().getMonth()+1,0).getDate();
  const allowance = Math.max(0,(income-fixed)/daysInMonth);
  const budgetSafeToday = income>0 && todayExpenses <= allowance*1.15;
  const uniqueLogged = new Set(expenses.map(e=>String(e.date||"").slice(0,10)).filter(Boolean)).size;
  return {d,totalSaved,completedGoals,maxGoalPct,uniqueLogged,budgetSafeToday,available};
}
function updateAchievementState(){
  const m=achievementMetrics(), d=m.d, today=dayKey();
  if(m.budgetSafeToday && !d.budgetDays.includes(today)){
    d.budgetDays.push(today);
    d.budgetDays=d.budgetDays.slice(-120);
    d.budgetStreak = d.budgetStreak+1;
    d.bestStreak=Math.max(d.bestStreak,d.budgetStreak);
  } else if(!m.budgetSafeToday){
    d.budgetStreak=0;
  }
  if(Array.isArray(data.expenses) && data.expenses.some(e=>String(e.date||"").slice(0,10)===today) && !d.loggedDays.includes(today)){
    d.loggedDays.push(today);
    d.loggedDays=d.loggedDays.slice(-365);
  }
  saveAchData(d);
}
function achievementValue(a,m){
  if(a.type==="budget") return Math.min(a.goal,m.d.budgetDays.length);
  if(a.type==="saving") return Math.min(a.goal,m.totalSaved);
  if(a.type==="logging") return Math.min(a.goal,m.d.loggedDays.length);
  if(a.type==="goal") return Math.min(a.goal,m.completedGoals);
  if(a.type==="goal50") return Math.min(a.goal,m.maxGoalPct);
  if(a.type==="streak") return Math.min(a.goal,m.d.bestStreak);
  return 0;
}
function renderAchievements(){
  const box=document.getElementById("achievementsGrid"); if(!box) return;
  updateAchievementState();
  const m=achievementMetrics();
  let xp=0, unlocked=0;
  const cards=ACHIEVEMENTS.map(a=>{
    const value=achievementValue(a,m);
    const pct=Math.min(100,Math.round(value/a.goal*100));
    const done=value>=a.goal;
    if(done){xp+=a.xp;unlocked++;}
    return `<div class="achievement-item ${done?'unlocked':'locked'}">
      ${done?'<div class="achievement-check">✓</div>':''}
      <div class="achievement-icon">${a.icon}</div>
      <div class="achievement-name">${a.name}</div>
      <div class="achievement-desc">${a.desc}</div>
      <div class="achievement-progress"><i style="width:${pct}%"></i></div>
      <div class="achievement-foot"><span>${Math.round(value).toLocaleString('ar-EG')} / ${a.goal.toLocaleString('ar-EG')}</span><b>+${a.xp} XP</b></div>
    </div>`;
  }).join("");
  box.innerHTML=cards;
  const level=Math.floor(xp/100)+1, current=xp%100, next=100-current;
  const titles=["بداية قوية","متحكم في فلوسك","موفّر ذكي","مخطط محترف","ملك الميزانية","أسطورة الزوكش"];
  document.getElementById("levelBadge").textContent=`Lv. ${level}`;
  document.getElementById("levelTitle").textContent=titles[Math.min(titles.length-1,level-1)];
  document.getElementById("xpText").textContent=`${current} / 100 XP`;
  document.getElementById("xpBar").style.width=`${current}%`;
  document.getElementById("nextLevelText").textContent=`${next===100?100:next} XP للمستوى التالي`;
  document.getElementById("achievementUnlocked").textContent=unlocked;
  document.getElementById("achievementTotal").textContent=ACHIEVEMENTS.length;
  document.getElementById("achievementStreak").textContent=m.d.budgetStreak;
}

function render(){let month=selected.slice(0,7),spMonth=data.expenses.filter(x=>x.date.startsWith(month)).reduce((a,x)=>a+x.amount,0),spDay=data.expenses.filter(x=>x.date===today()).reduce((a,x)=>a+x.amount,0),free=data.income-data.fixed-spMonth,tasks=data.tasks.filter(x=>x.date===today()),done=tasks.filter(x=>x.done).length,maxStreak=data.habits.length?Math.max(...data.habits.map(h=>streak(h.id))):0;$("dateText").textContent=new Date().toLocaleDateString("ar-EG",{weekday:"long",day:"numeric",month:"long"});$("sFree").textContent=money(free);$("sSpend").textContent=money(spDay);$("sStreak").textContent=maxStreak+" يوم";$("sGoals").textContent=data.goals.filter(g=>g.current<g.target).length+"/"+data.goals.length;$("mFree").textContent=money(free);$("mIncome").textContent=money(data.income);$("mSpend").textContent=money(spMonth);$("mSaved").textContent=money(data.saved);$("mCommit").textContent=money(data.installments.reduce((a,x)=>a+x.amount*(x.count-x.paid),0));$("incomeIn").value=data.income||"";$("fixedIn").value=data.fixed||"";$("profileName").textContent=data.name||"زوكش";renderHome(tasks);renderMoney(month);renderFinanceDashboard(month);renderSmartHighlights();renderForecast();renderMoneyAlert();renderDay();renderCalendar();if($("searchInput"))searchAll()}
function renderHome(tasks){$("homeTasks").innerHTML=tasks.length?tasks.slice(0,5).map(t=>`<div class="row"><button class="check ${t.done?"on":""}" onclick="toggleTask(${t.id})">${t.done?"✓":""}</button><div class="grow ${t.done?"strike":""}">${esc(t.name)}<span class="muted">اليوم</span></div></div>`).join(""):'<div class="empty">مفيش مهام النهارده.</div>';let g=[...data.goals].sort((a,b)=>(a.current/a.target)-(b.current/b.target))[0];$("homeGoal").innerHTML=g?goalHTML(g):'<div class="empty">أضف هدف جديد.</div>'}
function goalHTML(g){let p=Math.min(100,Math.round(g.current/g.target*100));return `<div class="row"><div class="grow"><b>🎯 ${esc(g.name)}</b><span class="muted">${money(g.current)} من ${money(g.target)} • الموعد ${g.deadline}</span><div class="goalbar"><i style="width:${p}%"></i></div><span class="muted">${p}% إنجاز</span></div><button class="link" onclick="updateGoal(${g.id})">تحديث</button></div>`}
function renderMoney(month){let e=data.expenses.filter(x=>x.date.startsWith(month)),max=Math.max(1,...e.map(x=>x.amount)),by={};e.forEach(x=>by[x.date.slice(-2)]=(by[x.date.slice(-2)]||0)+x.amount);let keys=Object.keys(by).slice(-10);$("bars").innerHTML=keys.length?keys.map(k=>`<div class="bar"><i style="height:${Math.max(5,by[k]/max*100)}%"></i><small>${k}</small></div>`).join(""):'<div class="empty">مفيش بيانات كفاية.</div>';$("goals").innerHTML=data.goals.map(goalHTML).join("")||'<div class="empty">مفيش أهداف.</div>';$("installments").innerHTML=data.installments.map(x=>`<div class="row"><div class="grow"><b>📌 ${esc(x.name)}</b><span class="muted">${money(x.amount)} • ${x.due}</span><div class="installbar"><i style="width:${x.paid/x.count*100}%"></i></div><span class="pill">${x.paid}/${x.count} مدفوع</span></div><button class="link" onclick="payInstallment(${x.id})">دفع</button></div>`).join("")||'<div class="empty">مفيش أقساط.</div>';$("expenses").innerHTML=e.slice().reverse().slice(0,12).map(x=>`<div class="row"><div class="grow"><b>${esc(x.name)}</b><span class="muted">${x.date}</span></div><b>${money(x.amount)}</b></div>`).join("")||'<div class="empty">مفيش مصاريف.</div>'}
function renderDay(){let ts=data.tasks.filter(x=>x.date===selected),done=ts.filter(x=>x.done).length,p=ts.length?Math.round(done/ts.length*100):0;$("selLabel").textContent=new Date(selected+"T12:00:00").toLocaleDateString("ar-EG",{weekday:"long",day:"numeric",month:"long"});$("selPct").textContent=p+"% إنجاز";$("selBar").style.width=p+"%";$("habits").innerHTML=data.habits.map(h=>`<div class="row habit"><button class="check ${data.habitLogs[h.id+"_"+selected]?"on":""}" onclick="toggleHabit(${h.id})">${data.habitLogs[h.id+"_"+selected]?"✓":""}</button><div class="grow"><b>${h.icon} ${esc(h.name)}</b><span class="muted">أفضل Streak: ${bestStreak(h.id)} يوم</span></div><span class="streak">🔥 ${streak(h.id)}</span></div>`).join("")||'<div class="empty">أضف عادة.</div>';$("tasks").innerHTML=ts.map(t=>`<div class="row"><button class="check ${t.done?"on":""}" onclick="toggleTask(${t.id})">${t.done?"✓":""}</button><div class="grow ${t.done?"strike":""}">${esc(t.name)}</div></div>`).join("")||'<div class="empty">مفيش مهام لليوم ده.</div>';let r=data.reminders.filter(x=>x.date===selected);$("reminders").innerHTML=r.map(x=>`<div class="row">🔔<div class="grow"><b>${esc(x.name)}</b><span class="muted">${x.date}</span></div><b>${x.time}</b></div>`).join("")||'<div class="empty">مفيش تذكيرات.</div>'}

// ---------- Smart local Egyptian-Arabic assistant ----------
let pendingActions = [];

function normalizeArabic(s){
  return String(s||"")
    .replace(/[إأآٱ]/g,"ا").replace(/ى/g,"ي").replace(/ة/g,"ه")
    .replace(/ؤ/g,"و").replace(/ئ/g,"ي")
    .replace(/[٠-٩]/g,d=>"٠١٢٣٤٥٦٧٨٩".indexOf(d))
    .replace(/[۰-۹]/g,d=>"۰۱۲۳۴۵۶۷۸۹".indexOf(d))
    .replace(/[٬،]/g,",").replace(/[٫]/g,".")
    .toLowerCase().trim();
}
function numbersFrom(s){
  const z=String(s||"").replace(/[٠-٩]/g,d=>"٠١٢٣٤٥٦٧٨٩".indexOf(d)).replace(/[۰-۹]/g,d=>"۰۱۲۳۴۵۶۷۸۹".indexOf(d));
  return (z.match(/\d+(?:[.,]\d+)?/g)||[]).map(x=>Number(x.replace(",","."))).filter(Number.isFinite);
}
function cleanName(s){
  return String(s||"")
    .replace(/\d+(?:[.,]\d+)?/g,"")
    .replace(/جنيه|جنية|جنيهات|ج\b|مصري|المصري|على|علي|بتاع|بتوع|في|من|يوم\s*\d{1,2}/gi,"")
    .replace(/^(انا|أنا|ممكن|عايز|عاوزه|عاوز|لو سمحت|سجل|سجلي|ضيف|اضف|اعمل|اعملي|حط|حطلي|عندي|عليا|عليا|دفعت|صرف|صرفت|حوش|حوشت|توفير|ادخار|هدف|عادة|روتين|مهمة|قسط|التزام)\s*/gi,"")
    .replace(/\s+/g," ").trim();
}
function addChat(w,t){data.chat.push({w,t})}
function ask(x){$("msg").value=x;send()}
function renderChat(){
  const el=$("chat");
  if(!el) return;
  const items=Array.isArray(data.chat)?data.chat:[];
  el.innerHTML=items.map(m=>`<div class="msg ${m.w==="u"?"u":"b"}">${m.t||""}</div>`).join("");
  el.scrollTop=el.scrollHeight;
}
function send(){
  const q=$("msg").value.trim(); if(!q)return;
  addChat("u",esc(q));
  const result=smartUnderstand(q);
  if(result.actions?.length){
    result.actions.forEach(a=>queueAction(a));
    if(result.text)addChat("b",result.text);
  }else addChat("b",result.text||"🤖 مش فاهمك بالكامل لسه.");
  $("msg").value=""; save(); renderChat();
}
function queueAction(action){
  const id=pendingActions.push(action)-1;
  addChat("b",`<div class="confirmCard" id="confirm-${id}"><b>⚠️ محتاج تأكيدك</b><p>${action.summary}</p><div class="confirmBtns"><button class="confirmYes" onclick="confirmAction(${id})">تأكيد وتنفيذ</button><button class="confirmNo" onclick="cancelAction(${id})">إلغاء</button></div></div>`);
}
function confirmAction(id){
  const a=pendingActions[id];
  if(!a||a.status)return;
  a.status="done";
  let text=executeAction(a);
  addChat("b",`✅ ${text}`);
  save(); renderChat();
}
function cancelAction(id){
  const a=pendingActions[id];
  if(!a||a.status)return;
  a.status="cancelled";
  addChat("b","تمام، لغيت العملية ومغيرتش أي بيانات.");
  save(); renderChat();
}
function executeAction(a){
  const p=a.payload;
  if(a.type==="expense"){data.expenses.unshift({id:uid(),name:p.name,amount:p.amount,date:p.date});return `اتسجل مصروف ${money(p.amount)} في «${esc(p.name)}» بتاريخ ${p.date}.`}
  if(a.type==="income"){data.income=p.amount;return `سجلت الدخل الشهري ${money(p.amount)}.`}
  if(a.type==="fixed"){data.fixed=p.amount;return `سجلت المصاريف الثابتة ${money(p.amount)}.`}
  if(a.type==="saving"){data.saved+=p.amount;return `زودت التوفير ${money(p.amount)}. إجمالي التوفير دلوقتي ${money(data.saved)}.`}
  if(a.type==="goal"){data.goals.push({id:uid(),name:p.name,target:p.target,current:p.current||0,deadline:p.deadline});return `أضفت هدف «${esc(p.name)}» بقيمة ${money(p.target)} وموعد ${p.deadline}.`}
  if(a.type==="habit"){data.habits.push({id:uid(),name:p.name,icon:p.icon||"🔥"});return `أضفت عادة «${esc(p.name)}».`}
  if(a.type==="task"){data.tasks.push({id:uid(),name:p.name,date:p.date,done:false});return `أضفت مهمة «${esc(p.name)}» ليوم ${p.date}.`}
  if(a.type==="completeTask"){const x=data.tasks.find(t=>t.id===p.id);if(!x)return "المهمة مش موجودة.";x.done=true;return `علمت مهمة «${esc(x.name)}» كمكتملة.`}
  if(a.type==="installment"){data.installments.push({id:uid(),name:p.name,amount:p.amount,count:p.count||1,paid:0,due:p.due});return `أضفت «${esc(p.name)}» بقيمة ${money(p.amount)}، والاستحقاق ${p.due}.`}
  if(a.type==="payInstallment"){const x=data.installments.find(i=>i.id===p.id);if(!x)return "القسط مش موجود.";x.paid=Math.min(x.count,x.paid+1);return `سجلت دفعة لقسط «${esc(x.name)}».`}
  if(a.type==="reminder"){data.reminders.push({id:uid(),name:p.name,time:p.time,date:p.date});return `أضفت تذكير «${esc(p.name)}» الساعة ${p.time}.`}
  if(a.type==="deleteExpense"){const i=data.expenses.findIndex(x=>x.id===p.id);if(i<0)return "المصروف مش موجود.";const x=data.expenses.splice(i,1)[0];return `حذفت مصروف «${esc(x.name)}» بقيمة ${money(x.amount)}.`}
  return "تم تنفيذ العملية."
}
function dateObj(s){return new Date(s+"T12:00:00")}
function sumExpenses(list){return list.reduce((a,x)=>a+Number(x.amount||0),0)}
function financeWindow(days){
  const end=dateObj(selected), start=new Date(end);
  start.setDate(start.getDate()-(days-1));
  return data.expenses.filter(x=>{const d=dateObj(x.date);return d>=start&&d<=end});
}
function unpaidInstallments(){
  return data.installments.reduce((a,x)=>a+Number(x.amount||0)*Math.max(0,Number(x.count||0)-Number(x.paid||0)),0);
}
function goalStats(){
  if(!data.goals.length)return {avg:0,done:0,active:0,rows:[]};
  const rows=data.goals.map(g=>{
    const pct=Math.min(100,Math.max(0,Math.round((Number(g.current||0)/Math.max(1,Number(g.target||0)))*100)));
    return {g,pct};
  });
  return {
    avg:Math.round(rows.reduce((a,x)=>a+x.pct,0)/rows.length),
    done:rows.filter(x=>x.pct>=100).length,
    active:rows.filter(x=>x.pct<100).length,
    rows
  };
}
function weeklyMonthlySummary(){
  const week=financeWindow(7);
  const month=data.expenses.filter(x=>x.date.startsWith(selected.slice(0,7)));
  const wSpend=sumExpenses(week), mSpend=sumExpenses(month);
  const weeklyDaily=wSpend/7, monthlyDaily=mSpend/Math.max(1,new Date(dateObj(selected).getFullYear(),dateObj(selected).getMonth()+1,0).getDate());
  const commitments=unpaidInstallments();
  const availableBeforeFuture=data.income-data.fixed-mSpend;
  const availableAfterInstallments=availableBeforeFuture-commitments;
  const savingRate=data.income>0?(data.saved/data.income*100):0;
  const monthExpenseRate=data.income>0?(mSpend/data.income*100):0;
  const g=goalStats();
  const biggest=month.slice().sort((a,b)=>b.amount-a.amount)[0];
  const categories={};
  month.forEach(x=>categories[x.name]=(categories[x.name]||0)+Number(x.amount||0));
  const topCats=Object.entries(categories).sort((a,b)=>b[1]-a[1]).slice(0,3);
  return {wSpend,mSpend,weeklyDaily,monthlyDaily,commitments,availableBeforeFuture,availableAfterInstallments,savingRate,monthExpenseRate,g,biggest,topCats};
}
function statsText(){
  const s=weeklyMonthlySummary();
  const top=s.topCats.length?s.topCats.map(x=>`${x[0]} ${money(x[1])}`).join(" • "):"مفيش تصنيفات";
  const goalLine=s.g.rows.length?s.g.rows.map(x=>`${x.g.name}: ${x.pct}%`).join(" • "):"مفيش أهداف";
  return `📊 التحليل المالي المتقدم
• الدخل الشهري: ${money(data.income)}
• مصاريف الشهر: ${money(s.mSpend)} (${Math.round(s.monthExpenseRate)}% من الدخل)
• المصاريف الثابتة: ${money(data.fixed)}
• الأقساط والالتزامات المتبقية: ${money(s.commitments)}
• المتاح بعد مصاريف الشهر والأقساط: ${money(s.availableAfterInstallments)}
• التوفير المتراكم: ${money(data.saved)}
• نسبة التوفير من الدخل: ${s.savingRate.toFixed(1)}%

📅 الأسبوع
• مصروف آخر 7 أيام: ${money(s.wSpend)}
• متوسط الصرف اليومي: ${money(Math.round(s.weeklyDaily))}

🗓️ الشهر
• متوسط الصرف اليومي: ${money(Math.round(s.monthlyDaily))}
• أعلى بند: ${s.biggest?`${s.biggest.name} — ${money(s.biggest.amount)}`:"لا يوجد"}
• أكبر البنود: ${top}

🎯 الأهداف
• مكتملة: ${s.g.done}
• قيد الإنجاز: ${s.g.active}
• متوسط التقدم: ${s.g.avg}%
• ${goalLine}

💡 ملاحظة: «المتاح بعد الأقساط» هنا يحسب كل المتبقي من دفعات الأقساط المسجلة، وليس قسط الشهر الحالي فقط.`;
}
function naturalDate(q){
  const s=normalizeArabic(q), base=new Date(selected+"T12:00:00");
  if(/بكره|غدا|بكره/.test(s))base.setDate(base.getDate()+1);
  if(/بعد بكره/.test(s))base.setDate(base.getDate()+2);
  return base.toISOString().slice(0,10);
}
function smartUnderstand(q){
  const s=normalizeArabic(q), nums=numbersFrom(q), n=nums[0]||0;
  const date=naturalDate(q);

  // Pure questions / analysis — no confirmation needed.
  if(/(ملخص|تقرير|تحليل).*(اسبوع|اسبوعي|اخر 7|٧ ايام|سبع ايام)/.test(s)){
    const x=weeklyMonthlySummary();
    return {text:`📅 ملخص الأسبوع
• المصروف: ${money(x.wSpend)}
• متوسط اليوم: ${money(Math.round(x.weeklyDaily))}
• المتاح بعد مصروف الشهر والأقساط: ${money(x.availableAfterInstallments)}
• نسبة التوفير من الدخل: ${x.savingRate.toFixed(1)}%`};
  }
  if(/(ملخص|تقرير|تحليل).*(شهر|شهري|الشهر ده|هذا الشهر)/.test(s)){
    const x=weeklyMonthlySummary();
    return {text:`🗓️ ملخص الشهر
• المصروف: ${money(x.mSpend)}
• الثابت: ${money(data.fixed)}
• الأقساط المتبقية: ${money(x.commitments)}
• المتاح بعد المصاريف والأقساط: ${money(x.availableAfterInstallments)}
• نسبة المصروف من الدخل: ${x.monthExpenseRate.toFixed(1)}%
• نسبة التوفير من الدخل: ${x.savingRate.toFixed(1)}%
• متوسط تقدم الأهداف: ${x.g.avg}%`};
  }
  if(/^(حلل|حللي|اعمل تحليل|وريني|قولي|قوليلي|ايه اخبار|عامل ايه|عامله ايه).*(فلوس|ميزاني|مصروف|دخل|اقساط|اهداف|عادات)|حلل فلوسي|حلل ميزانيتي|وضعي المالي|انا واقف فين/.test(s))
    return {text:statsText()};
  if(/كام.*(مصروف|صرف)|مصروفي.*(كام|قد ايه)|صرفت كام/.test(s)){
    const spend=data.expenses.filter(x=>x.date.startsWith(selected.slice(0,7))).reduce((a,x)=>a+x.amount,0);
    return {text:`💸 مصروف الشهر ${money(spend)}، ومصروف النهارده ${money(data.expenses.filter(x=>x.date===selected).reduce((a,x)=>a+x.amount,0))}.`};
  }
  if(/فاضل|متبقي|معايا كام|المتاح|الفلوس المتاحه|المتاحه/.test(s)&&/(فلوس|جنيه|دخل|مرتب|ميزاني)/.test(s))
    return {text:`💜 المتاح الحسابي حاليًا ${money(data.income-data.fixed-data.expenses.filter(x=>x.date.startsWith(selected.slice(0,7))).reduce((a,x)=>a+x.amount,0))}. ده قبل أي مصاريف مستقبلية.`};
  if(/عليا.*(قسط|اقساط|التزام)|اقساطي|الاقساط.*كام/.test(s)){
    const debt=data.installments.reduce((a,x)=>a+x.amount*Math.max(0,x.count-x.paid),0);
    return {text:`📌 عليك حاليًا ${money(debt)} في الأقساط. ${data.installments.map(x=>`${x.name}: ${Math.max(0,x.count-x.paid)} دفعة`).join(" • ")}`};
  }
  if(/اهدافي|اهداف|الهدف.*فين|التوفير.*هدف/.test(s)){
    if(!data.goals.length)return {text:"🎯 مفيش أهداف مسجلة لسه."};
    return {text:"🎯 أهدافك: "+data.goals.map(g=>`${g.name} ${Math.min(100,Math.round(g.current/g.target*100))}% (${money(g.current)}/${money(g.target)})`).join(" • ")};
  }
  if(/عاداتي|عادات|ستريك|streak/.test(s))
    return {text:data.habits.length?`🔥 عاداتك: ${data.habits.map(h=>`${h.icon} ${h.name}: ${streak(h.id)} يوم`).join(" • ")}`:"مفيش عادات مسجلة."};
  if(/مهام.*اليوم|مهامي|اعمل ايه النهارده|النهارده.*اعمل/.test(s)){
    const ts=data.tasks.filter(t=>t.date===selected);
    return {text:ts.length?`📋 عندك ${ts.length} مهام: ${ts.map(t=>`${t.done?"✅":"⬜"} ${t.name}`).join(" • ")}`:"يومك فاضي من المهام. تحب أضيفلك مهمة؟"};
  }

  // Mutations — always ask for confirmation.
  if(/(مرتبي|راتبي|قبضي|دخلي|المرتب|الراتب)/.test(s)&&n)
    return {text:"",actions:[{type:"income",payload:{amount:n},summary:`تسجيل الدخل الشهري = ${money(n)}. القيمة الحالية ${money(data.income)} هتتغير.`}]};
  if(/(الثابت|مصاريفي الثابته|المصاريف الثابته)/.test(s)&&n)
    return {text:"",actions:[{type:"fixed",payload:{amount:n},summary:`تعديل المصاريف الثابتة إلى ${money(n)}.`}]};
  if(/(حوشت|حوش|حطيت.*توفير|زودت.*توفير|ادخرت|ادخار)/.test(s)&&n)
    return {text:"",actions:[{type:"saving",payload:{amount:n},summary:`إضافة ${money(n)} إلى التوفير. التوفير الحالي ${money(data.saved)}.`}]};
  if(/(صرف|صرفت|دفعت|دفعتهم|مصروف)/.test(s)&&n){
    let name=cleanName(q)||"مصروف";
    return {text:"",actions:[{type:"expense",payload:{name,amount:n,date},summary:`تسجيل مصروف ${money(n)} باسم «${esc(name)}» بتاريخ ${date}.`}]};
  }
  if(/(اعمل|اعملي|اضف|ضيف|زود).*?(عادة|روتين)/.test(s)){
    let name=cleanName(q)||"عادة جديدة";
    return {text:"",actions:[{type:"habit",payload:{name,icon:"🔥"},summary:`إضافة عادة جديدة باسم «${esc(name)}».`}]};
  }
  if(/(حط|اعمل|اضف|ضيف).*?(هدف)/.test(s)&&n){
    let name=cleanName(q).replace(/هدف/g,"").trim()||"هدف جديد";
    const deadline=(q.match(/(?:يوم|بتاريخ|موعد)\s*(\d{1,2})/)||[])[1];
    let dl=new Date(selected+"T12:00:00"); dl.setDate(deadline?Number(deadline):dl.getDate()+30);
    return {text:"",actions:[{type:"goal",payload:{name,target:n,current:0,deadline:dl.toISOString().slice(0,10)},summary:`إضافة هدف «${esc(name)}» بقيمة ${money(n)} وموعد ${dl.toISOString().slice(0,10)}.`}]};
  }
  if(/(قسط|التزام)/.test(s)&&n){
    const dm=q.match(/يوم\s*(\d{1,2})/),day=dm?Number(dm[1]):15;
    const d=new Date(selected+"T12:00:00");d.setDate(day);
    let name=cleanName(q).replace(/قسط|التزام/g,"").trim()||"قسط جديد";
    return {text:"",actions:[{type:"installment",payload:{name,amount:n,count:nums[1]||1,due:d.toISOString().slice(0,10)},summary:`إضافة قسط «${esc(name)}» بقيمة ${money(n)}، ${nums[1]||1} دفعة، والاستحقاق ${d.toISOString().slice(0,10)}.`}]};
  }
  if(/(اضف|ضيف|اعمل|اعملي).*(مهمه|مهمة|ذاكره|مذاكره|رياضه|مشوار|شغل)/.test(s)){
    let name=cleanName(q).replace(/مهمه|مهمة/g,"").trim()||"مهمة جديدة";
    return {text:"",actions:[{type:"task",payload:{name,date},summary:`إضافة مهمة «${esc(name)}» ليوم ${date}.`}]};
  }
  if(/(خلصت|انجزت|تمت|عملت).*(مهمه|مهمة)/.test(s)){
    const open=data.tasks.find(t=>t.date===selected&&!t.done);
    if(!open)return {text:"مفيش مهمة مفتوحة النهارده."};
    return {text:"",actions:[{type:"completeTask",payload:{id:open.id},summary:`تحديد مهمة «${esc(open.name)}» كمكتملة.`}]};
  }
  if(/(فكرني|فكرني|ذكرني|افتكرني|تذكير)/.test(s)){
    const tm=(q.match(/(?:الساعه|الساعة|الساعة)\s*(\d{1,2})(?::(\d{2}))?/)||[]);
    const time=tm[1]?`${String(tm[1]).padStart(2,"0")}:${tm[2]||"00"}`:"21:00";
    let name=cleanName(q).replace(/فكرني|ذكرني|افتكرني|تذكير|الساعه|الساعة/gi,"").trim()||"تذكير";
    return {text:"",actions:[{type:"reminder",payload:{name,time,date},summary:`إضافة تذكير «${esc(name)}» يوم ${date} الساعة ${time}.`}]};
  }
  if(/(امسح|احذف|شيل).*(مصروف|صرف)/.test(s)){
    const key=cleanName(q).replace(/مصروف|صرف/g,"").trim();
    const x=data.expenses.find(e=>!key||e.name.toLowerCase().includes(key.toLowerCase()));
    if(!x)return {text:"مش لاقي مصروف مناسب للحذف."};
    return {text:"",actions:[{type:"deleteExpense",payload:{id:x.id},summary:`حذف مصروف «${esc(x.name)}» بقيمة ${money(x.amount)} بتاريخ ${x.date}.`}]};
  }

  // Natural budgeting advice, without changing data.
  if(/عايز اوفر|عاوز اوفر|محتاج اوفر|ازاي اوفر|عايز احوش|عاوز احوش/.test(s)){
    const x=weeklyMonthlySummary();
    const suggested=Math.max(0,Math.round(Math.max(0,x.availableAfterInstallments)*.25/50)*50);
    const target=x.g.rows.find(g=>g.pct<100);
    const goalAdvice=target?` وأقرب هدف «${target.g.name}» ناقصه ${money(Math.max(0,target.g.target-target.g.current))}.`:"";
    return {text:`💡 بعد مصاريف الشهر والأقساط، المتاح الحسابي ${money(x.availableAfterInstallments)}. اقتراح مبدئي: وفر حوالي ${money(suggested)} إذا كان مناسب لالتزاماتك.${goalAdvice}`};
  }
  if(/سلام|اهلا|أهلا|ازيك|عامل ايه|عامل ايه/.test(s))return {text:"أهلاً يا زوكش 👋 قولّي عايز تعمل إيه وأنا أساعدك."};
  if(/بتعمل ايه|تقدر تعمل ايه|اوامرك|أوامرك|صلاحياتك/.test(s))
    return {text:"🤖 أقدر أفهم مصري في: الدخل، المصاريف، التوفير، الميزانية، الأقساط، الأهداف، العادات، المهام والتذكيرات. أقدر كمان أعمل تحليلات وأبحث في بياناتك. أي تعديل على بياناتك لازم أطلب تأكيدك الأول."};
  return {text:"🤖 فهمت إنك بتكلمني بشكل طبيعي، بس الجملة دي مش واضحة كفاية عندي. جرّب مثلًا: «قبضي 8000»، «أنا صرفت 70 مواصلات»، «حوشت 500»، «عليا أقساط كام؟»، أو «حلل فلوسي»."};
}
$("msg").addEventListener("keydown",e=>{if(e.key==="Enter")send()});render();renderChat();if("serviceWorker"in navigator)navigator.serviceWorker.register("./sw.js").catch(()=>{})